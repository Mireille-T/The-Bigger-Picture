Add extension icons of the following dimensions here (will be used in extension previews):
- 16 x 16 px
- 32 x 32 px
- 48 x 48 px
- 128 x 128 px
